package lab6;
public class Square extends Shape {

}public class Triangle extends Shape{
    private Integer l;
     super(l);

    @Override
    public Double area() { return Double.valueOf(l+l)

    }
    @Override
    public Integer per(){
        return 1*1;
    }
}


