package lab6;

public class Triangle extends Shape{
   public Triangle(Integer l){}
     super(l);

    @Override
    public Double area() { return Double.valueOf(l+l)

    }
    @Override
    public Integer per(){
        return 1*1;
    }
}



