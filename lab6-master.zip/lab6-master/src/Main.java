package lab6;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void  main (String[] args){
        //Triangle triangle= new Triangle(5);
        //Square square= new Square(6)
         //triangle.desen();
        //square.desen();
        List<Book>listaDeCarti= new ArrayList<>();
        List<String>listaDeString= new ArrayList<>();

        listaDeCarti.add(new Book("Book1","Author1","1234"));
        listaDeCarti.add(new Book("Book2","Author2","2234"));
        listaDeCarti.add(new Book("Book3","Author3","3234"));
        Book book1= listaDeCarti.get();
    }
}
